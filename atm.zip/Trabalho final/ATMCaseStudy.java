// ATMCaseStudy.java
// Driver program for the ATM case study

public class ATMCaseStudy
{
    // main method creates and runs the ATM
    public static void main( String[] args )
    {
        ATM1 theATM = new ATM1();
        theATM.run();
    } // end main
} // end class ATMCaseStudy