public class ecran
{
    public void mostrarMensagem(String mensagem)
    {
        System.out.println(mensagem);
    }

    public void mostrarMensagemParagrafo(String mensagem)
    {
        System.out.println(mensagem);
    }
    
    public void mostrarMensagemEuros(double quantidade)
    {
        System.out.print(quantidade+"€");
    }
}